create   procedure AddStudent2 (@p_fname varchar(30), @p_lname varchar(50), @p_tallness int) as
  begin
    declare
      @login char(6),
      @mail varchar(50)

    set @login=substring(lower(@p_lname),1,3) + '000';
    set @mail=@login+'@vsb.cz';
    insert into Student (login, fname, lname, email)  values (@login, @p_fname, @p_lname, @mail);
  end
go

