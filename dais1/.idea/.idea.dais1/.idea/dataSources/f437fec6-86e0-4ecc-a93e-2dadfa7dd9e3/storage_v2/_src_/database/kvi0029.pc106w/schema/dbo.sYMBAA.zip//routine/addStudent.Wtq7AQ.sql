create   procedure addStudent(@p_login char(6), @p_fname varchar(30), @p_lname varchar(50), @p_email varchar(50)) as
  begin 
  insert into Student(login, fname, lname, email) values (@p_login, @p_fname, @p_lname, @p_email);
end;
go

