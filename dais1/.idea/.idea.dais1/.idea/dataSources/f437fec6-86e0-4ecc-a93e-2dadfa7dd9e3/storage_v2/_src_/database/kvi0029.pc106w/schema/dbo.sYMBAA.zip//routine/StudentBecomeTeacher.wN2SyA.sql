create   procedure StudentBecomeTeacher (@p_login char(6)) as
begin
  declare
    @fname varchar(30),
    @lname varchar(50),
    @email varchar(50)
  begin transaction ;
  begin try
    select @fname=fname, @lname=lname, @email=email from Student where @p_login= login;
    insert Teacher(login, fname, lname, email, department) values (@p_login, @fname, @lname, @email, 1);
    delete from Student where @p_login=login;
    commit
end try
  begin catch
    rollback
  end catch
end
go

