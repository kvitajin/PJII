create   procedure IsStudenTall(@p_login char(6)) as
begin
  declare @avg int;
  select @avg=avg(tallness)from Student;
  if ((select tallness from Student where login =@p_login) >@avg)
    update Student set tallness=1 where login=@p_login

end
go

