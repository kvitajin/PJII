create   procedure SetStudentTallness as
  begin
    declare @v_login char(6);
    declare c cursor for select login from Student;
    open c;
    fetch from c into @v_login;
    while @@fetch_status=0
    begin
      exec IsStudentTall @v_login
      fetch from c into  @v_login;
    end
    close c;
    deallocate c;
  end
go

