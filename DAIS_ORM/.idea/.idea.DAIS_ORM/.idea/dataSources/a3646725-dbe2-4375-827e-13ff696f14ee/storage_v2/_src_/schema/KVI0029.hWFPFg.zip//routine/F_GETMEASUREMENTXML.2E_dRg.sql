create FUNCTION f_GetMeasurementXML(p_from DATE, p_to DATE) RETURN VARCHAR2 AS
v_result CLOB;
BEGIN
    v_result := '<report>';
    v_result := v_result || CHR(13) || CHR(10);
    FOR c_station IN (SELECT station_id, station_name FROM Station s WHERE EXISTS(SELECT station_id FROM Measurement m WHERE m.station_id = s.station_id AND m.meas_date BETWEEN p_from AND p_to))
    LOOP
        v_result := v_result || '<station id="' || to_char(c_station.station_Id) || '" name="' || to_char(c_station.station_name) || '">';
        v_result := v_result || CHR(13) || CHR(10);
        FOR c_measurement IN (SELECT meas_id, meas_date, concentration, sub.substance_id, sub.substance_name, sub.limit FROM Measurement m LEFT JOIN Substance sub on m.substance_id = sub.substance_id WHERE m.station_id = c_station.station_id AND meas_date BETWEEN p_from AND p_to)
        LOOP
            v_result := v_result || '  <measurement id="' || to_char(c_measurement.meas_id) || '">';
            v_result := v_result || CHR(13) || CHR(10);
            v_result := v_result || '    <date>' || to_char(c_measurement.meas_date) || '</date>';
            v_result := v_result || CHR(13) || CHR(10);
            v_result := v_result || '    <concentration>' || to_char(c_measurement.concentration) || '</concentration>';
            v_result := v_result || CHR(13) || CHR(10);
            v_result := v_result || '    <substance id="' || to_char(c_measurement.substance_id) || '">';
            v_result := v_result || CHR(13) || CHR(10);
            v_result := v_result || '      <name>' || to_char(c_measurement.substance_name) || '</name>';
            v_result := v_result || CHR(13) || CHR(10);
            v_result := v_result || '      <limit>' || to_char(c_measurement.limit) || '</limit>';
            v_result := v_result || CHR(13) || CHR(10);
            v_result := v_result || '    </substance>';
            v_result := v_result || CHR(13) || CHR(10);
            v_result := v_result || '  </measurement>';
            v_result := v_result || CHR(13) || CHR(10);
        END LOOP;
        v_result := v_result || '</station>';
        v_result := v_result || CHR(13) || CHR(10);
    END LOOP;
    v_result := v_result || '</report>';
    RETURN v_result;
END f_GetMeasurementXML;
/

