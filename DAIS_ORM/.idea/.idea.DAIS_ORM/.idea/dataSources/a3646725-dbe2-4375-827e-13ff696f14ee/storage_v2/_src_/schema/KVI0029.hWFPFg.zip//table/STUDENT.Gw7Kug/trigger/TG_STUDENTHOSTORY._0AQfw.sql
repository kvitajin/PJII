create trigger TG_STUDENTHOSTORY
  before update
  on STUDENT
  for each row
begin
    if updating ('fname')then
      insert into StudentHistory(login, columnName, oldValue, newValue, dateTime) values (:new.LOGIN, 'fname', :old.LNAME, :new.FNAME, current_timestamp);
    end if;
    if updating ('lname') then
      insert into StudentHistory(login, columnName, oldValue, newValue, dateTime) values (:new.LOGIN, 'lname', :old.LNAME, :new.LNAME, current_timestamp);
    end if;
    if updating ('tallness') then
      insert into StudentHistory(login, columnName, oldValue, newValue, dateTime) values (:new.LOGIN, 'tallness', :old.TALLNESS, :new.TALLNESS, current_timestamp);
    end if;
  end;
/

