create trigger OPERATIONCOUNT
  after insert or update or delete
  on STUDENT
begin
    if inserting then
      update statistics set insertCount= insertCount+1;
    elsif updating then
      update statistics set updateCount= updateCount+1;
    elsif deleting then
      update statistics set deleteCount= deleteCount+1;
    else
      DBMS_OUTPUT.put_line('error');
    end if;
  end;
/

