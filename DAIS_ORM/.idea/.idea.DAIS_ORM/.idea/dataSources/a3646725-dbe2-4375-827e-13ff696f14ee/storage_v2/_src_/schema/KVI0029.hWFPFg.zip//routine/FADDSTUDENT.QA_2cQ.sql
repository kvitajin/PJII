create function FAddStudent(p_login VARCHAR2, p_fname varchar2, p_lname varchar2, p_tallness int) return varchar2 as
begin
  insert into STUDENT (LOGIN, FNAME, LNAME, TALLNESS) values (p_login, p_fname, p_lname, p_tallness);
  return 'ok';
exception
  when others then
  return 'error';
end;
/

