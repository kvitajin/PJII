create trigger ZAPAS_INSERT
  before insert
  on ZAPAS
  for each row
begin
  select zapas_seq.nextval into :new.idZapas from dual;
end;
/

