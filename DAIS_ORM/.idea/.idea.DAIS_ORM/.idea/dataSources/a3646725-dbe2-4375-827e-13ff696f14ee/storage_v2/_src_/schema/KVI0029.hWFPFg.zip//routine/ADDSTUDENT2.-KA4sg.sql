create procedure AddStudent2(p_fname varchar2,p_lname varchar2, p_tallness varchar2) as
    v_login STUDENT.login%TYPE;
    v_i int;
  begin
    v_i:=0;
     loop
      v_login :=substr(p_lname, 1,3) ||LPAD(TO_CHAR(v_i), 2, '0');
      v_i:= v_i+1;
      exit when not LoginExist(v_login);
    end loop;
    insert into STUDENT(login, fname, lname, tallness) values (v_login, p_fname, p_lname, p_tallness);
    commit;
  exception
    when others then
      DBMS_OUTPUT.put_line('error');
      rollback;
  end;
/

