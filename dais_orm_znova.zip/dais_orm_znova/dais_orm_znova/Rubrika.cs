namespace dais_orm_znova {
    public class Rubrika {
        public int RubrikaId { get; set; }
        public string Nazev { get; set; }
    }
}