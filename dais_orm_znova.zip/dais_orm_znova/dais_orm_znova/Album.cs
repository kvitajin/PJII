using System;

namespace dais_orm_znova {
    public class Album {
        public int AlbumId { get; set; }
        public string Nazev { get; set; }
        public int ObecId { get; set; }
        public int Visible { get; set; }
    }
}