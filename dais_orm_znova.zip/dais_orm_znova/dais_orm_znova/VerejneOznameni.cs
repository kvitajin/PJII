using System;

namespace dais_orm_znova {
    public class VerejneOznameni {
        public DateTime DatumVyves { get; set; }
        public DateTime DatumStazeni { get; set; }
        public int DokumentId { get; set; }
        
    }
}