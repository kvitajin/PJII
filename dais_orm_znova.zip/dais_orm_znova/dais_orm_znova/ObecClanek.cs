namespace dais_orm_znova {
    public class ObecClanek {
        private int ObecId { get; set; }
        private int DokumentId { get; set; }
    }
}