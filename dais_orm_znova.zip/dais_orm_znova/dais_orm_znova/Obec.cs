namespace dais_orm_znova {
    public class Obec {
        public int ObecId { get; set; }
        public string Nazev { get; set; }
        public int Visible { get; set; }
    }
}