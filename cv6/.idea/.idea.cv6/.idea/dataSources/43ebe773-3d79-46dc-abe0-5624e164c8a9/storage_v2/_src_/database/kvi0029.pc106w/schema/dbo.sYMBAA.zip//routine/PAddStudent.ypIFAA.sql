create   procedure PAddStudent(@p_login char, @p_fname varchar, @p_lname varchar, @p_email varchar, @p_result bit output) as
  begin 
    begin try 
        insert into Student(login, fname, lname, email) values (@p_login, @p_fname, @p_lname, @p_email);
        set @p_result=1;
    end try
    begin catch
      set  @p_result=0;
    end catch
  end
go

